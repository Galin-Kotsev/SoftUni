﻿namespace BorderControl
{
    public interface IIdentifable
    {
        public string Id { get; set; }
    }
}