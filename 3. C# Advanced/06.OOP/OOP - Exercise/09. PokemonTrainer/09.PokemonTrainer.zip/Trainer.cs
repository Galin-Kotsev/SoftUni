﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _09._PokemonTrainer
{
    public  class Trainer
    {
        private string name;
        private int numberOfBadges;
        
        public Trainer(string name)
        {
            Name = name;
            NumberOfBadges = 0;
            Pokemons = new List<Pokemon>();
        }

        public string Name 
        { 
            get { return name; }
            set { name = value; }
        }
        public int CollectionOfPokemon
        { 
            get { return CollectionOfPokemon; } 
            set { CollectionOfPokemon = value; } 
        }
        public int NumberOfBadges
        {
            get { return numberOfBadges; }
            set { numberOfBadges =value; }
        }
        public List<Pokemon> Pokemons
        {
            get; set;
        }
       
    }
}
