﻿namespace BorderControl
{
    public interface ICitizen
    {
        public string Name { get; set; }
        public int Age { get; set; }

    }
}