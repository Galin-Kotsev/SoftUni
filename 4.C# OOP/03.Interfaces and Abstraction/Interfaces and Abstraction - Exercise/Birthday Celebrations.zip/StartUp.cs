﻿using System.Collections.Immutable;

namespace BorderControl
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            string input = string.Empty;

            List<IBirthable> Ids = new List<IBirthable>();

            while ((input = Console.ReadLine()) != "End")
            {
                string[] tokens = input
                    .Split(" ",StringSplitOptions.RemoveEmptyEntries);

                if (tokens[0] == "Citizen")
                {
                    string name = tokens[1];
                    int age = int.Parse(tokens[2]);
                    string id = tokens[3];
                    string birthdate = tokens[4];

                    Ids.Add(new Citizen(name, age, id, birthdate));
                }
                else if (tokens[0] == "Pet")
                {
                    string name = tokens[1];
                    string birthdate = tokens[2];

                    Ids.Add(new Pet(name,birthdate));
                }
            }

            string idSearch = Console.ReadLine();

            foreach (var i in Ids)
            {
                if (i.Birthdate.ToString().EndsWith(idSearch))
                {
                    Console.WriteLine(i.Birthdate);
                }
            }
        }
    }
}