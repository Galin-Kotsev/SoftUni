﻿namespace Telephony
{
    public interface IWeb
    {
        public string Browsing(string site);
    }
}
