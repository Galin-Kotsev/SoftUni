﻿namespace BorderControl
{
    public interface ICitizen
    {
        public int Age { get; set; }
        public string Birthdate { get; set; }

    }
}