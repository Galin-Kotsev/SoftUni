﻿namespace Telephony
{
    public interface IPhone
    {
        public string Calling(string number);
    }
}
