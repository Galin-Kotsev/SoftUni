﻿namespace NeedForSpeed
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            RaceMotorcycle Car = new RaceMotorcycle(20, 10);
            System.Console.WriteLine(Car.Fuel);
            Car.Drive(10);
            System.Console.WriteLine(Car.Fuel);
            
        }
    }
}
